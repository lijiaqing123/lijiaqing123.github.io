<?php
/**
 * Child-Theme functions and definitions
 */

function main_child_scripts() {
    wp_enqueue_style( 'main-parent-style', get_template_directory_uri(). '/style.css' );
    if (is_rtl()) {
 		wp_enqueue_style( 'main-rtl-style', get_template_directory_uri(). '/rtl.css' );
    }
}
add_action( 'wp_enqueue_scripts', 'main_child_scripts' );
 
?>